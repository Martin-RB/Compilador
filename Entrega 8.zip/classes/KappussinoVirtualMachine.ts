export class KapussinoVirtualMachine{
    
    constructor(){
        
    }
}