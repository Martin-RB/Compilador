"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var KapussinoVirtualMachine = /** @class */ (function () {
    function KapussinoVirtualMachine() {
    }
    return KapussinoVirtualMachine;
}());
exports.KapussinoVirtualMachine = KapussinoVirtualMachine;
